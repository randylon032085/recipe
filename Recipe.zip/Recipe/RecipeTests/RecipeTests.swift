//
//  RecipeTests.swift
//  RecipeTests
//
//  Created by Randylon Torda on 11/20/24.
//

import Testing
@testable import Recipe

struct RecipeTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
