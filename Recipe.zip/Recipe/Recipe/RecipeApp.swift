//
//  RecipeApp.swift
//  Recipe
//
//  Created by Randylon Torda on 11/20/24.
//

import SwiftUI

@main
struct RecipeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
